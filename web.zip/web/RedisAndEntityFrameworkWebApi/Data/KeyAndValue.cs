namespace RedisAndEntityFrameworkInWebApi.Data;

public class KeyAndValue
{
        public string Key { get; set; }
        public string Value { get; set; }
}