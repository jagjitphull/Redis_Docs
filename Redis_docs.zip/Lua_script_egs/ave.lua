local function average(key)
  local sum = 0
  local count = 0
  for i, element in ipairs(redis.lrange(key, 0, -1)) do
    sum = sum + tonumber(element)
    count = count + 1
  end
  return sum / count
end

return average

