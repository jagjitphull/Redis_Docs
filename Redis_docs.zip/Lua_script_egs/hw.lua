local key = KEYS[1]
local value = ARGV[1]
redis.call('SET', key, value)
return value
